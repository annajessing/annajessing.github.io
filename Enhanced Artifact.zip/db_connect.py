# Corner Grocer Application
# Connection to Database

# Programmer: Anna Jessing
# Last Updated: April 15, 2026

#####################################################################################
### This file contains code to connect to the database that stores purchase history   
### of produce items at Corner Grocer. Database queries are also defined here.
###
### The following database queries are included in this file:
###   1. READ - view items in database
###
### A prior SNHU assignment was referenced to assist in the development of this code:
### Jessing, A. (2025). Animal_Shelter.py [Unpublished code]. CS-340: Client/Server
###    Development, Southern New Hampshire University.
#####################################################################################

from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi

class DBConnect(object):

    def __init__(self, username, password): 

        self.USER = username
        self.PASS = password
        self.CLUSTER = "cornergrocer.uso918h.mongodb.net/?appName=CornerGrocer"

        self.mongo_uri = "mongodb+srv://" + self.USER + ":" + self.PASS + "@" + self.CLUSTER
        self.client = MongoClient(self.mongo_uri, server_api=ServerApi('1'))

        # verify the correct username and password combination
        self.client.admin.command("ping")


    # Implement Read Query
    def read(self, item_name):   
        try:
            database = self.client.get_database("corner_grocer_sales")
            collection = database.get_collection("produce_sales")

            if item_name is not None:      

                # check to see if this is a find all or find one query
                if item_name == {}:
                    cursor = collection.find({}) 

                else:
                    # check to see if entry can be found
                    query = { "item_name" : item_name }
                    cursor = collection.find_one(query)

                self.client.close() 
                    
                # list is empty - find() unsuccessful
                if not cursor:   
                    return []          
                # return items found - find() successful
                else:           
                    return cursor 
  
            else:
                # parameter is empty - find() unsuccessful
                raise Exception("Nothing to read, because data parameter is empty")
            
        except Exception as e:
            raise Exception("Unable to find the document due to the following error: ", e)