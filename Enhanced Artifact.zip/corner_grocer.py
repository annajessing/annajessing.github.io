# Corner Grocer Application
# Main Application Logic

# Programmer: Anna Jessing
# Last Updated: April 15, 2026

#####################################################################################
### This application allows users to look up purchase history of produce items at  
### Corner Grocer. Purchase history information will be stored in MongoDB, so when 
### the user selects a menu option, a database query is performed. 
###
### Users can navigate the menu options to perform the following actions:
###   1. See how many times a single produce item has been purchased
###   2. See how many times each produce item has been purchased (numerical format)
###   3. See how many times each produce item has been purchased (histogram format)
#####################################################################################

from db_connect import DBConnect
from pymongo.errors import PyMongoError

# built in libraries used to help with string validation and masking password input
import re
import pwinput

# used to validate user input for username and password
# does NOT check for correct username and password combo - this is handled by Mongo Atlas
def validate_user_login():
    username_valid = bool(False)
    password_valid = bool(False)
    username_attempt = str("")
    password_attempt = str("")

    # to validate user input
    username_regex_pattern = r"^[a-zA-Z]{3,15}$"
    password_regex_pattern = r"^[a-zA-Z0-9]{5,25}$"

    while not username_valid:
        # user enters username
        try:
            username_attempt = str(input("\nEnter username: "))

        # unexpected error occurs
        except ValueError as e:
            print("Invalid input:",e,"\n")

        # user enters string, so verify that the string is allowed
        else:
            # user enters a string between 3 and 15 characters that only contains letters
            if re.fullmatch(username_regex_pattern, username_attempt):
                username_valid = True
            else:
                print("Your input is invalid. Please try again.\n")
    
    while not password_valid:
        # user enters password - mask input with '*'
        try:
            password_attempt = str(pwinput.pwinput(prompt="\nEnter password: ", mask='*'))

        # unexpected error occurs
        except ValueError as e:
            print("Invalid input:", e, "\n")

        # user enters string, so verify that the string is allowed
        else:
            # user does not enter a string between 5 and 15 characters that only contains letters and numbers
            if re.fullmatch(password_regex_pattern, password_attempt):
                password_valid = True
            else:
                print("Your input is invalid. Please try again.\n")

    return username_attempt, password_attempt


def user_login():
    successful_connection = False
    db = str("")

    while not successful_connection:
        db_username, db_password = validate_user_login()

        # attempt to connect to database
        try:
            db = DBConnect(db_username, db_password)

        # if the username/password is incorrect (or another error occurs), the connection will fail
        except PyMongoError as e:
            print("Connection to Corner Grocer's Sales dataset failed:", e)

        else:
            successful_connection = True

    return db


# used to dynamically create strings before printing them to keep formatting consistent 
def create_char_string(max_string_length, char_to_print, extra_char):
    # create string where 'char_to_print' is printed (max_string_length - extra_char) number of times
    # max_string_length = char_to_print + extra_char
    char_string = char_to_print * (max_string_length - extra_char)
    return char_string


# used to validate user input when user wants to look up purchase
# history of an item (menu option 1)
def validate_item_name(db):
    item_sold = bool(False)
    lookup_item = str("N/A")
    num_items_purchased = int(-1)

    # to validate user input
    regex_pattern = r"^[a-zA-Z ]{3,15}$"

    while not item_sold:
        # user enters menu option, must be an integer
        try:
            user_entered_item_name = str(input("\nEnter the name of the item you would like to look up: "))
        
        # unexpected error occurs
        except ValueError as e:
            print("Invalid input:", e, "\n")
        
        # user enters string, so verify the option exists in the database
        else:
            # user does enter a string between 3 and 15 characters that only contains letters
            if re.fullmatch(regex_pattern, user_entered_item_name):
                
                lookup_item = user_entered_item_name.lower()

                # query database for single item
                # database queries will include error handling
                one_item = db.read(lookup_item)

                # user can type 'help' to view a list of what options they can select in order to 
                # prevent an infinite loop because the user does not know what options are valid
                if lookup_item == "help":

                    # query database for all items
                    # database queries will include error handling
                    all_items = db.read({})

                    # extract name of item and print all items
                    print("\nValid options include:")       
                    for item in all_items:
                        item_name = str(item.get("item_name"))
                        print(item_name)
                        
                # lookup_item is not in the database 
                elif not one_item:
                    print("That item was not found in our records. Please try again.\n")
                    print("To see a list of items you could select, enter 'help' when asked for an item name.\n")

                # lookup_item is in the database
                else:
                    num_items_purchased = one_item.get("num_purchased")
                    item_sold = True
            
            # user does NOT enter a string between 3 and 15 characters that only contains letters
            else:
                print("Your input is invalid. Please try again.\n")

    return lookup_item, num_items_purchased


# menu option 3
def purchase_history_all_items_histogram(db):
    histogram_char = str("*")
    col_width = int(25)

    # query database for all items
    # database queries will include error handling
    all_items = db.read({})

    print("\nEach star represents 5 items purchased:")

    # for each produce item, print item name and number of items sold in a histogram format
    for item in all_items:

        # extract name of item and how many were purchased
        item_name = str(item.get("item_name"))
        num_purchased = int(item.get("num_purchased"))

        # configure strings to help with formatting
        print_spaces = create_char_string(col_width - len(item_name), " ", 0)
        print_stars = create_char_string(num_purchased//5, histogram_char, 0)

        # print formatted string
        print(item_name, print_spaces, print_stars)

    print("\n")


# menu option 2
def purchase_history_all_items_numerical(db):
    col_width = int(25)

    # query database for all items
    # database queries will include error handling
    all_items = db.read({})

    print("\n")

    # for each produce item, print item name and number of items sold
    for item in all_items:

        # extract name of item and how many were purchased
        item_name = str(item.get("item_name"))
        num_purchased = int(item.get("num_purchased"))

        # configure strings to help with formatting
        print_separator = create_char_string(col_width - len(item_name), ".", 0)

        print(item_name, print_separator, num_purchased) 

    print("\n")


# menu option 1
def purchase_history_one_item(db):
    # gather user input and validate before querying database
    item_name, number_of_items_sold = validate_item_name(db)

    # print out item name and how many times it was sold
    print("\n")
    print(item_name, ":   ", number_of_items_sold, "\n")


# gather user input and validate that it is an integer between 1-4
def validate_menu_selection():

    # initialize variable so it is not null going into the loop
    user_menu_selection = int(0)  

    # set the min and max options available in user_menu_select() and print_menu()
    menu_selection_min = int(1)
    menu_selection_max = int(4)

    # validate user input
    while not(menu_selection_min <= user_menu_selection <= menu_selection_max):

        # user enters menu option, must be an integer
        try:
            user_menu_selection = int(input("Please select a menu option to continue (enter 1, 2, 3, or 4): "))
        # user does not enter an integer or some other error occurs
        except ValueError:
            print("Something went wrong. Please select a valid menu option, which must be a whole number between 1 and 4.\n")
        # user enters integer, so verify that option exists in the menu
        else:
            if not(menu_selection_min <= user_menu_selection <= menu_selection_max):
                print("That is not a valid menu option.\n")
    
    return user_menu_selection


def print_menu():
    # changing this value will change the width of the menu
    menu_width = int(67)

    # to keep formatting consistent across all lines
    menu_start_str = str("** ")
    menu_end_str = str("*")

    # define all menu options
    menu_option_one = str("1 - Look Up Purchase History of A Specific Item")
    menu_option_two = str("2 - Print All Items and Their Purchase History (Numerical)")
    menu_option_three = str("3 - Print All Items and Their Purchase History (Histogram)")
    menu_option_four = str("4 - Exit Program")

    menu_options = [menu_option_one, menu_option_two, menu_option_three, menu_option_four]

    # print top of menu
    print("*" * menu_width)

    # print formatted strings that include the following components and do NOT have a separating character
        # menu start string (for formatting purposes)
        # menu option 
        # char_string = a series of spaces (for formatting purposes)
        # menu end string (for formatting purposes)
    for option in menu_options:
        char_string = create_char_string(menu_width, ' ', len(option) + len(menu_start_str) + len(menu_end_str))
        print(menu_start_str, option, char_string, menu_end_str, sep="")

    # print bottom of menu
    print("*" * menu_width, "\n")
    

def user_menu_select(db):
    # initialize variable so it is not null going into the loop
    user_choice = int(-1)

    # while user does not want to exit the program
    while user_choice != 4:

        print_menu()

        # gather input from the user
        # input will be validated to ensure input is a number between 1 and 4 before moving forward
        user_choice = validate_menu_selection()

        # call proper function to execute the user's desired action
        if user_choice == 1:
            purchase_history_one_item(db)

        elif user_choice == 2:
            purchase_history_all_items_numerical(db)

        elif user_choice == 3:
            purchase_history_all_items_histogram(db)

        elif user_choice == 4:
            # exit program
            break 


def main():
    # set up database connection
    db = user_login()

    # begin user interaction with program
    user_menu_select(db)


if __name__=="__main__":
    main()
